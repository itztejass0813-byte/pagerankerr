const players=[
  {id:"A",name:"ALEX",role:"PLAYMAKER",x:27,y:43,links:["B","C"]},
  {id:"B",name:"BRUNO",role:"MIDFIELDER",x:48,y:28,links:["C"]},
  {id:"C",name:"CARLO",role:"FORWARD",x:73,y:42,links:["A"]},
  {id:"D",name:"DIEGO",role:"WINGER",x:52,y:70,links:["A","C"]}
];

let ranks={A:.25,B:.25,C:.25,D:.25};
let minute=0, round=1, score=[0,0], playing=false, timer=null;

const $=s=>document.querySelector(s);
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const fmtPct=n=>`${(n*100).toFixed(1)}%`;

function calculate(){
  const d=.85,n=players.length;
  const next={A:(1-d)/n,B:(1-d)/n,C:(1-d)/n,D:(1-d)/n};
  players.forEach(p=>p.links.forEach(to=>next[to]+=d*ranks[p.id]/p.links.length));
  return next;
}
function sorted(){return [...players].sort((a,b)=>ranks[b.id]-ranks[a.id])}
function renderPlayers(){
  const host=$("#players"); host.innerHTML="";
  players.forEach(p=>{
    const el=document.createElement("div");
    el.className="player "+(sorted()[0].id===p.id?"top":"");
    el.style.left=p.x+"%"; el.style.top=p.y+"%";
    el.innerHTML=`<div class="player-rank">${fmtPct(ranks[p.id])}</div><div class="player-core">${p.id}</div><div class="player-name">${p.name}</div>`;
    host.appendChild(el);
  });
}
function renderNetwork(){
  const svg=$("#network"); svg.innerHTML="";
  players.forEach(p=>p.links.forEach(to=>{
    const q=players.find(x=>x.id===to);
    const strong=ranks[p.id]+ranks[q.id]>.52;
    const line=document.createElementNS("http://www.w3.org/2000/svg","line");
    line.setAttribute("x1",p.x);line.setAttribute("y1",p.y);line.setAttribute("x2",q.x);line.setAttribute("y2",q.y);
    line.setAttribute("class","pass-line"+(strong?" strong":""));
    svg.appendChild(line);
  }));
}
function renderRanks(){
  const box=$("#rankings"); box.innerHTML="";
  sorted().forEach((p,i)=>{
    const row=document.createElement("div"); row.className="rank-row";
    row.innerHTML=`<div class="rank-no">${String(i+1).padStart(2,"0")}</div>
      <div><div class="rank-name">${p.name}<small>${p.role} • ${p.links.length} outgoing links</small></div>
      <div class="meter"><span style="width:${ranks[p.id]*100*2.7}%"></span></div></div>
      <div class="rank-value">${fmtPct(ranks[p.id])}</div>`;
    box.appendChild(row);
  });
  $("#roundBadge").textContent=`ROUND ${round}`;
}
function render(){
  $("#minute").textContent=`${String(Math.floor(minute/60)).padStart(2,"0")}:${String(minute%60).padStart(2,"0")}`;
  $("#score").textContent=`${score[0]} — ${score[1]}`;
  renderPlayers();renderNetwork();renderRanks();
}
function addEvent(text,icon="⚽"){
  const feed=$("#feed"), div=document.createElement("div");div.className="event";
  div.innerHTML=`<span class="event-time">${String(minute).padStart(2,"0")}'</span><span class="event-icon">${icon}</span><span>${text}</span>`;
  feed.prepend(div);
  while(feed.children.length>8)feed.lastChild.remove();
}
function toast(t){const el=$("#toast");el.textContent=t;el.classList.add("show");clearTimeout(window.toastT);window.toastT=setTimeout(()=>el.classList.remove("show"),1800)}
function moveBall(from,to){
  const a=players.find(p=>p.id===from),b=players.find(p=>p.id===to),ball=$("#ball");
  ball.style.left=a.x+"%";ball.style.top=a.y+"%";ball.classList.remove("fly");
  void ball.offsetWidth; ball.style.left=b.x+"%";ball.style.top=b.y+"%";ball.classList.add("fly");
  setTimeout(()=>ball.classList.remove("fly"),850);
}
function passOnce(){
  const source=players[Math.floor(Math.random()*players.length)];
  const target=source.links[Math.floor(Math.random()*source.links.length)];
  moveBall(source.id,target);
  addEvent(`<b>${source.name}</b> → <b>${target}</b> pass. Influence flows along the link.`,`↗`);
}
function attack(){
  passOnce();
  setTimeout(()=>{
    const shot=Math.random()<.24;
    if(shot){
      score[Math.random()<.5?0:1]++;
      addEvent(`<b>SHOT!</b> The passing chain creates a scoring chance.`,`🥅`);
      toast("Attack completed — a chance is created!");
    }else addEvent(`<b>Build-up continues.</b> The network keeps circulating influence.`,`🧠`);
    minute++;
    render();
  },500);
}
function nextMinute(){
  minute++;
  if(minute%5===0){
    ranks=calculate(); round++;
    const leader=sorted()[0];
    addEvent(`<b>${leader.name}</b> is now the network leader at ${fmtPct(ranks[leader.id])}.`,`📊`);
    toast(`PageRank updated: ${leader.name} leads`);
  }else{
    passOnce();
    addEvent(`Possession phase. Current leader: <b>${sorted()[0].name}</b>.`,`🟢`);
  }
  render();
}
function showFlow(){
  let i=0;
  const links=players.flatMap(p=>p.links.map(to=>[p.id,to]));
  const timer2=setInterval(()=>{
    if(i>=links.length){clearInterval(timer2);return}
    moveBall(...links[i]); i++;
  },650);
  toast("Watch the network: every arrow is a possible pass.");
}
function predict(){
  const top=sorted()[0];
  toast(`Current PageRank leader: ${top.name} (${fmtPct(ranks[top.id])})`);
  addEvent(`<b>ANALYST PICK:</b> ${top.name} has the highest current PageRank.`,`🎯`);
}
function reset(){
  clearInterval(timer);playing=false;
  ranks={A:.25,B:.25,C:.25,D:.25};minute=0;round=1;score=[0,0];
  $("#feed").innerHTML="";
  addEvent("<b>Kick-off.</b> All four players begin with equal PageRank: 25%.","🏁");
  render();
}
$("#playBtn").onclick=()=>{
  if(playing){clearInterval(timer);playing=false;$("#playBtn").textContent="▶ PLAY MATCH";toast("Match paused");return}
  playing=true;$("#playBtn").textContent="Ⅱ PAUSE MATCH";
  timer=setInterval(nextMinute,1300);
};
$("#attackBtn").onclick=attack;
$("#flowBtn").onclick=showFlow;
$("#stepBtn").onclick=nextMinute;
$("#resetBtn").onclick=reset;
reset();
