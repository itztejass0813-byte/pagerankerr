# ⚽ PageRank FC — Football Intelligence Lab

An interactive football simulation that teaches **Google's PageRank idea** through a passing network.

> **Core analogy:** a football player is a node, a pass is a directed link, and PageRank estimates influence inside the network.

## ✨ Features

- Realistic night-match / broadcast-style interface
- Animated football pitch and player markers
- Live passing network
- PageRank calculations with damping factor `d = 0.85`
- Match clock, score, attack simulation and event feed
- Ranked influence panel with animated meters
- Responsive layout for desktop and mobile
- No backend, build step, framework or database required
- Uses only HTML, CSS and vanilla JavaScript

## 🧠 How PageRank works here

The simulation uses four fictional players:

| Player | Passes to |
|---|---|
| Alex | Bruno, Carlo |
| Bruno | Carlo |
| Carlo | Alex |
| Diego | Alex, Carlo |

Every player starts with:

`PageRank = 0.25`

For each update:

```text
PR(p) = (1 - d) / N + d × Σ(PR(q) / L(q))
```

The project uses:

```text
d = 0.85
N = 4
```

That means 85% of the score follows the passing links and 15% is a baseline contribution.

### Important football interpretation

PageRank is **not a complete football rating**.

A high PageRank means the player is important in this particular network of passes. It does not automatically mean the player is the best scorer, defender, fastest player or overall best footballer.

## 🚀 Run locally

No installation is required.

1. Download or clone this repository.
2. Open `index.html` in a browser.

For the smoothest local development experience, use VS Code with the **Live Server** extension.

## 🌐 Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload:
   - `index.html`
   - `style.css`
   - `script.js`
   - `README.md`
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`.
6. Save.
7. GitHub will publish the site at your repository's Pages address.

## 🎮 Controls

- **Play Match** — automatically advances the match.
- **Simulate Attack** — animates a pass and creates a chance.
- **Show Pass Flow** — sends the ball through the passing network.
- **Next Minute** — manually advances one minute.
- **Reset** — returns every player to 25%.

Every 5 simulated minutes, the PageRank values are recalculated.

## 📚 Learning sources

The PageRank concept is based on the original Google/Stanford work:

- Brin & Page, *The Anatomy of a Large-Scale Hypertextual Web Search Engine*  
  https://infolab.stanford.edu/~backrub/google.html
- Stanford, *Mining of Massive Datasets*  
  https://infolab.stanford.edu/~ullman/mmds/book.pdf
- Google Research, PageRank publication archive  
  https://research.google/pubs/archive/334.pdf

## 🛠️ Tech stack

- HTML5
- CSS3
- Vanilla JavaScript
- SVG for the passing network
- Google Fonts: Barlow Condensed + Inter

## 📄 License

Use and modify this educational project freely for learning and personal projects. If you publish a substantially modified version, keeping an attribution note is appreciated.
